Read me

this is the first version of the pack 

you need to

/tag @s add admin //if u want to get people crative and more
if u want to make people on survival get a commandblock
and put this command
/tag @a add s 